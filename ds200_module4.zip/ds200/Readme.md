Dataset used - statement_5_2013_14_1.csv
Available at - https://data.gov.in/catalogs/ministry_department/ministry-corporate-affairs

Plotted Scatter plot, Box plot and line plot for the columns "No. of Companies- Total" and "Authorized capital- Total".These are the last 2 columns of the dataset.

Observations - There is a positive correlation between these 2 columns as is evident from Scatter Plot.
Hence the Scatter plot is most suitable for such datasets where there is some correlation between the columns.
