import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

#create dataframe
df=pd.read_csv("statement_5_2013_14_1.csv",header=0,usecols=['No. of Companies - Total','Authorized Capital - Total'],index_col=['No. of Companies - Total'])

#plot scatter with first column as x values and second column as y values
#plt.scatter(df['col6'],df['col7'],color='#dd12dd',label="scatter-label")

#specifying labels
#plt.xlabel("No. of Companies- Total")
#plt.ylabel("Authorized capital- Total")

#enable legend
#plt.legend()
#plt.show()
#print(df.head())
df.to_csv("new.csv")
df2=pd.read_csv("new.csv",header=1,names=['col1','col2'])
print(df2.head())
plt.scatter(df2['col1'],df2['col2'],color='#dd12dd',label="scatter-label")
plt.xlabel("No. of Companies- Total")
plt.ylabel("Authorized capital- Total")

#enable legend
plt.legend()
plt.show()

