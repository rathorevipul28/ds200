import pandas as pd
import matplotlib.pyplot as plt
#import sys
#create dataframe from csv
df=pd.read_csv("statement_5_2013_14_1.csv", header=0, usecols=['No. of Companies - Total','Authorized Capital - Total'],index_col=['No. of Companies - Total'])
plotMap=[]

#create a list of lists where each list will have a corresponding box plot
df.to_csv("new1.csv")
df2=pd.read_csv("new1.csv",header=1,names=['col1','col2'])
plotMap.append(df2['col1'].dropna().tolist())
plotMap.append(df2['col2'].dropna().tolist())

#plotting
plt.boxplot(plotMap)

#specifying labels
plt.xticks([1,2],["No. of Companies - Total","Authorized Capital - Total"])
plt.xlabel("Column_name")
plt.ylabel("Column_value")


plt.legend()
plt.show()
