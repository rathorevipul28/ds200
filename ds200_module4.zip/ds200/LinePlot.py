import pandas as pd
import matplotlib.pyplot as plt

#reading data frame from a csv file
df=pd.read_csv("statement_5_2013_14_1.csv", header=0, usecols=['No. of Companies - Total','Authorized Capital - Total'])

df.to_csv("new2.csv")
df2=pd.read_csv("new2.csv",header=0,names=['col1','col2'])
plt.plot(df2['col1'],df2['col2'],color='#ddbbaa',label="bar-label")

print(df2.head())
print(df2['col1'])
print(df2['col2'])
plt.xlabel("No. of Companies - Total")
plt.ylabel("Authorized Capital - Total")

#enabling legend
plt.legend()
plt.show()
